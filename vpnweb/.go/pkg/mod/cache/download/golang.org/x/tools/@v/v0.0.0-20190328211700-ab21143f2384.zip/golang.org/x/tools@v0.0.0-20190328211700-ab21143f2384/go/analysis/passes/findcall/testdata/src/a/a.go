package main

func main() {
	println("hi") // want "call of println"
	print("hi")   // not a call of println
}
