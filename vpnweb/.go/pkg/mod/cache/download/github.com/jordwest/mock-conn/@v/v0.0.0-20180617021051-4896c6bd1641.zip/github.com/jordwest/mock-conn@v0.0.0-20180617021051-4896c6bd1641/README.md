Mock connection for Golang
==========================

This is a simple simulation connection for mocking a net.Conn in golang.

Inspired by [this StackOverflow question](http://stackoverflow.com/questions/1976950/simulate-a-tcp-connection-in-go/30997282#30997282)


