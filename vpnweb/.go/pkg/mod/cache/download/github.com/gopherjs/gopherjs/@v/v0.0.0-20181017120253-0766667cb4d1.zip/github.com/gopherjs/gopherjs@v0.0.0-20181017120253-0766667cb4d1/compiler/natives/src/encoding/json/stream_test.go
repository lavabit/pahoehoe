// +build js

package json

import "testing"

func TestHTTPDecoding(t *testing.T) {
	t.Skip("network access is not supported by GopherJS")
}
