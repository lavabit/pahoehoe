// Package http DEPRECATED USE net/http/httptest
package http
